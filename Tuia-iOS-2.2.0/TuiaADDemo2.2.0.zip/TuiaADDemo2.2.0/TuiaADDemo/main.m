//
//  main.m
//  TaTmDemo
//
//  Created by  on 17/2/23.
//  Copyright © 2017年 dozening. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
