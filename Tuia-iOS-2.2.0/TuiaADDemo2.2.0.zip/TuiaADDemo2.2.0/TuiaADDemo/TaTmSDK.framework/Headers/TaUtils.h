//
//  TaUtils.h
//  AdIOSSDK
//
//  Created by doulai on 12/7/16.
//  Copyright © 2016 Ta. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface TaUtils : NSObject
+(void)addIconForView:(UIView*)parent paramter:(NSDictionary*)dic btn:(SEL )func  caller:(UIView*)callself;
@end
