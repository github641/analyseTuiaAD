//
//  TaAd.h
//  TaAd
//
//  Created by lc on 16/11/8.
//  Copyright © 2016年 Ta. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TaAd.
FOUNDATION_EXPORT double TaAdVersionNumber;

//! Project version string for TaAd.
FOUNDATION_EXPORT const unsigned char TaAdVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TaAd/PublicHeader.h>

#ifdef __OBJC__

#import <UIKit/UIKit.h>

#import "TaStreamerView.h"
#import "TaScreenView.h"
#import "TaInfoStreamerView.h"
#import "TaBnView.h"
#import "TaDriftView.h"
#import "TaAppWallView.h"
#import "TaLaunchScreenView.h"
#import "TaTmHelper.h"

#endif
/**
 *  用户信息可见类型
 */





